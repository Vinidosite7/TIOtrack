import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase-server'
import Sidebar from '@/components/layout/Sidebar'
import WorkspaceProvider from '@/components/layout/WorkspaceProvider'

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  return (
    <WorkspaceProvider>
      <div style={{
        display: 'flex',
        height: '100vh',
        background: '#07090F',
        overflow: 'hidden',
      }}>
        <Sidebar />
        <main style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
          minWidth: 0,
        }}>
          {children}
        </main>
      </div>
    </WorkspaceProvider>
  )
}