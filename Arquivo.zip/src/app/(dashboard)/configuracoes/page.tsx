'use client'

import { useState, useEffect } from 'react'
import { Save, CheckCircle } from 'lucide-react'
import { T } from '@/lib/tokens'
import { supabase } from '@/lib/supabase'
import { useWorkspaceStore } from '@/store/workspace'

function Input({ value, onChange, placeholder, prefix }: {
  value: string
  onChange: (v: string) => void
  placeholder?: string
  prefix?: string
}) {
  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
      {prefix && (
        <span style={{
          position: 'absolute', left: 12,
          fontSize: 13, color: T.text3,
          pointerEvents: 'none',
        }}>{prefix}</span>
      )}
      <input
        type="number"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          width: '100%', height: 40,
          padding: prefix ? '0 12px 0 28px' : '0 12px',
          background: 'rgba(255,255,255,0.04)',
          border: `1px solid ${T.border}`,
          borderRadius: 8, color: T.text1, fontSize: 13,
          outline: 'none', boxSizing: 'border-box',
          fontFamily: T.mono,
        }}
      />
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ background: T.bgSurface, border: `1px solid ${T.border}`, borderRadius: 10, padding: '16px 20px' }}>
      <p style={{ fontSize: 11, color: T.text3, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 16 }}>
        {title}
      </p>
      {children}
    </div>
  )
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ fontSize: 12, color: T.text2, display: 'block', marginBottom: 6 }}>{label}</label>
      {children}
      {hint && <p style={{ fontSize: 11, color: T.text3, marginTop: 5 }}>{hint}</p>}
    </div>
  )
}

export default function ConfiguracoesPage() {
  const { active: workspace, list, setActive } = useWorkspaceStore()
  const [loading, setLoading]   = useState(true)
  const [saving, setSaving]     = useState(false)
  const [saved, setSaved]       = useState(false)

  const [metaMensal, setMetaMensal]       = useState('')
  const [custoPercent, setCustoPercent]   = useState('')
  const [alertaSaldo, setAlertaSaldo]     = useState('')
  const [nomeWorkspace, setNomeWorkspace] = useState('')

  useEffect(() => {
    if (!workspace?.id) return
    setNomeWorkspace(workspace.nome)
    loadPrefs(workspace.id)
  }, [workspace?.id])

  async function loadPrefs(wid: string) {
    setLoading(true)
    const { data } = await supabase
      .from('user_prefs')
      .select('meta_mensal_brl, custo_produto, alerta_saldo')
      .eq('workspace_id', wid)
      .single()

    if (data) {
      setMetaMensal(data.meta_mensal_brl?.toString() ?? '')
      setCustoPercent(data.custo_produto ? (data.custo_produto * 100).toString() : '')
      setAlertaSaldo(data.alerta_saldo?.toString() ?? '')
    }
    setLoading(false)
  }

  async function handleSave() {
    if (!workspace?.id) return
    setSaving(true)

    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    await supabase.from('user_prefs').upsert({
      user_id:        user.id,
      workspace_id:   workspace.id,
      meta_mensal_brl: metaMensal ? parseFloat(metaMensal) : null,
      custo_produto:   custoPercent ? parseFloat(custoPercent) / 100 : 0,
      alerta_saldo:    alertaSaldo ? parseFloat(alertaSaldo) : null,
      updated_at:      new Date().toISOString(),
    }, { onConflict: 'user_id,workspace_id' })

    // Atualiza nome do workspace se mudou
    if (nomeWorkspace && nomeWorkspace !== workspace.nome) {
      await supabase
        .from('workspaces')
        .update({ nome: nomeWorkspace })
        .eq('id', workspace.id)

      setActive({ ...workspace, nome: nomeWorkspace })
    }

    setSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>

      {/* Topbar */}
      <div style={{
        height: 48, borderBottom: `1px solid ${T.border}`,
        display: 'flex', alignItems: 'center',
        padding: '0 20px', gap: 8, flexShrink: 0,
      }}>
        <span style={{ fontSize: 13, fontWeight: 500, color: T.text1 }}>Configurações</span>
        <div style={{ flex: 1 }} />
        {saved && (
          <span style={{ fontSize: 12, color: T.green, display: 'flex', alignItems: 'center', gap: 5 }}>
            <CheckCircle size={13} /> Salvo
          </span>
        )}
        <button onClick={handleSave} disabled={saving} style={{
          height: 30, padding: '0 14px', borderRadius: 7,
          background: saving ? 'rgba(59,130,246,0.3)' : T.accent,
          border: 'none', color: '#fff', fontSize: 12, fontWeight: 500,
          display: 'flex', alignItems: 'center', gap: 6, cursor: saving ? 'not-allowed' : 'pointer',
        }}>
          <Save size={13} />
          {saving ? 'Salvando...' : 'Salvar'}
        </button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 600 }}>

        {loading ? (
          <div style={{ fontSize: 12, color: T.text3, textAlign: 'center', padding: 40 }}>Carregando...</div>
        ) : (
          <>
            <Section title="Workspace">
              <Field label="Nome do workspace">
                <input
                  type="text"
                  value={nomeWorkspace}
                  onChange={e => setNomeWorkspace(e.target.value)}
                  style={{
                    width: '100%', height: 40, padding: '0 12px',
                    background: 'rgba(255,255,255,0.04)',
                    border: `1px solid ${T.border}`,
                    borderRadius: 8, color: T.text1, fontSize: 13,
                    outline: 'none', boxSizing: 'border-box', fontFamily: T.sans,
                  }}
                />
              </Field>
            </Section>

            <Section title="Metas e finanças">
              <Field
                label="Meta de faturamento mensal (R$)"
                hint="Usado para calcular o progresso diário e projeção de fechamento do mês."
              >
                <Input value={metaMensal} onChange={setMetaMensal} placeholder="Ex: 80000" prefix="R$" />
              </Field>
              <Field
                label="Custo do produto (%)"
                hint="Percentual do faturamento que representa o custo do produto. Usado para calcular o lucro líquido real."
              >
                <Input value={custoPercent} onChange={setCustoPercent} placeholder="Ex: 30" prefix="%" />
              </Field>
            </Section>

            <Section title="Alertas">
              <Field
                label="Alertar quando saldo da BC for menor que (R$)"
                hint="Você receberá um alerta no dashboard quando qualquer conta de anúncio ficar abaixo deste valor."
              >
                <Input value={alertaSaldo} onChange={setAlertaSaldo} placeholder="Ex: 100" prefix="R$" />
              </Field>
            </Section>

            {list.length > 1 && (
              <Section title="Workspaces">
                {list.map(w => (
                  <div key={w.id} onClick={() => setActive(w)} style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '8px 10px', borderRadius: 8, cursor: 'pointer',
                    background: w.id === workspace?.id ? 'rgba(59,130,246,0.08)' : 'transparent',
                    border: `1px solid ${w.id === workspace?.id ? 'rgba(59,130,246,0.2)' : 'transparent'}`,
                    marginBottom: 6,
                  }}>
                    <div style={{
                      width: 8, height: 8, borderRadius: '50%',
                      background: w.id === workspace?.id ? T.accent : T.text3,
                    }} />
                    <span style={{ fontSize: 13, color: w.id === workspace?.id ? T.text1 : T.text2 }}>
                      {w.nome}
                    </span>
                    {w.id === workspace?.id && (
                      <span style={{ fontSize: 10, color: T.accent, marginLeft: 'auto', fontFamily: T.mono }}>ativo</span>
                    )}
                  </div>
                ))}
              </Section>
            )}
          </>
        )}
      </div>
    </div>
  )
}