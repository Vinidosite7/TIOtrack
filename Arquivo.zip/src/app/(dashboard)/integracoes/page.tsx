'use client'

import { useState, useEffect } from 'react'
import { Plus, Trash2, Eye, EyeOff, RefreshCw, CheckCircle, XCircle, AlertCircle } from 'lucide-react'
import { T } from '@/lib/tokens'
import { supabase } from '@/lib/supabase'
import { useWorkspaceStore } from '@/store/workspace'

// ── Tipos ──────────────────────────────────────────────────────
type BC = {
  id: string
  apelido: string
  bc_id: string
  ativo: boolean
  last_sync: string | null
  sync_status: string | null
  sync_error: string | null
  advertiser_accounts: {
    id: string
    advertiser_id: string
    nome: string | null
    balance: number | null
    status: string | null
  }[]
}

type FormData = {
  apelido: string
  bc_id: string
  access_token: string
  proxy_url: string
}

// ── Helpers ────────────────────────────────────────────────────
function toBRL(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'agora'
  if (mins < 60) return `${mins}min atrás`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h atrás`
  return `${Math.floor(hrs / 24)}d atrás`
}

// ── Componentes ────────────────────────────────────────────────
function SyncBadge({ status }: { status: string | null }) {
  if (!status || status === 'pending') return (
    <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, background: 'rgba(122,132,153,0.1)', color: T.text2, fontFamily: T.mono }}>pendente</span>
  )
  if (status === 'ok') return (
    <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, background: 'rgba(34,197,94,0.1)', color: T.green, fontFamily: T.mono, display: 'flex', alignItems: 'center', gap: 4 }}>
      <CheckCircle size={10} /> ok
    </span>
  )
  return (
    <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, background: 'rgba(239,68,68,0.1)', color: T.red, fontFamily: T.mono, display: 'flex', alignItems: 'center', gap: 4 }}>
      <XCircle size={10} /> erro
    </span>
  )
}

function SecretInput({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  const [show, setShow] = useState(false)
  return (
    <div style={{ position: 'relative' }}>
      <input
        type={show ? 'text' : 'password'}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          width: '100%', height: 38, padding: '0 36px 0 12px',
          background: 'rgba(255,255,255,0.04)',
          border: `1px solid ${T.border}`,
          borderRadius: 8, color: T.text1, fontSize: 13,
          outline: 'none', boxSizing: 'border-box', fontFamily: T.sans,
        }}
      />
      <button onClick={() => setShow(s => !s)} style={{
        position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)',
        color: T.text3, display: 'flex', alignItems: 'center',
      }}>
        {show ? <EyeOff size={14} /> : <Eye size={14} />}
      </button>
    </div>
  )
}

function Input({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <input
      type="text"
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      style={{
        width: '100%', height: 38, padding: '0 12px',
        background: 'rgba(255,255,255,0.04)',
        border: `1px solid ${T.border}`,
        borderRadius: 8, color: T.text1, fontSize: 13,
        outline: 'none', boxSizing: 'border-box', fontFamily: T.sans,
      }}
    />
  )
}

// ── Page ───────────────────────────────────────────────────────
export default function IntegracoesPage() {
  const { active: workspace } = useWorkspaceStore()
  const [bcs, setBcs]         = useState<BC[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving]   = useState(false)
  const [syncing, setSyncing] = useState<string | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [error, setError]     = useState('')
  const [success, setSuccess] = useState('')

  const [form, setForm] = useState<FormData>({
    apelido: '', bc_id: '', access_token: '', proxy_url: '',
  })

  async function loadBCs(wid: string) {
    setLoading(true)
    const { data } = await supabase
      .from('bc_configs')
      .select(`
        id, apelido, bc_id, ativo, last_sync, sync_status, sync_error,
        advertiser_accounts (id, advertiser_id, nome, balance, status)
      `)
      .eq('workspace_id', wid)
      .order('created_at', { ascending: true })

    setBcs((data as BC[]) ?? [])
    setLoading(false)
  }

  useEffect(() => {
    if (workspace?.id) loadBCs(workspace.id)
  }, [workspace?.id])

  async function handleSave() {
    if (!workspace?.id) return
    if (!form.apelido || !form.bc_id || !form.access_token) {
      setError('Apelido, BC ID e Access Token são obrigatórios.')
      return
    }

    setSaving(true)
    setError('')

    const { error: err } = await supabase
      .from('bc_configs')
      .insert({
        workspace_id: workspace.id,
        apelido:      form.apelido,
        bc_id:        form.bc_id,
        access_token: form.access_token,
        proxy_url:    form.proxy_url || null,
        ativo:        true,
      })

    if (err) {
      setError(err.message)
      setSaving(false)
      return
    }

    setForm({ apelido: '', bc_id: '', access_token: '', proxy_url: '' })
    setShowForm(false)
    setSuccess('BC adicionada com sucesso!')
    setTimeout(() => setSuccess(''), 3000)
    await loadBCs(workspace.id)
    setSaving(false)
  }

  async function handleDelete(bcId: string) {
    if (!confirm('Remover esta BC? Todos os dados de gasto vinculados serão mantidos.')) return
    await supabase.from('bc_configs').delete().eq('id', bcId)
    if (workspace?.id) loadBCs(workspace.id)
  }

  async function handleSync(bc: BC) {
    setSyncing(bc.id)
    // Chama a Edge Function de sync (vamos criar depois)
    const { error } = await supabase.functions.invoke('sync-bc', {
      body: { bc_config_id: bc.id, workspace_id: workspace?.id },
    })
    if (error) {
      await supabase.from('bc_configs').update({ sync_status: 'error', sync_error: error.message }).eq('id', bc.id)
    }
    if (workspace?.id) await loadBCs(workspace.id)
    setSyncing(null)
  }

  const label = (text: string) => (
    <label style={{ fontSize: 12, color: T.text2, display: 'block', marginBottom: 6 }}>{text}</label>
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>

      {/* Topbar */}
      <div style={{ height: 48, borderBottom: `1px solid ${T.border}`, display: 'flex', alignItems: 'center', padding: '0 20px', gap: 8, flexShrink: 0 }}>
        <span style={{ fontSize: 13, fontWeight: 500, color: T.text1 }}>Integrações</span>
        <div style={{ flex: 1 }} />
        <button onClick={() => setShowForm(s => !s)} style={{
          height: 30, padding: '0 12px', borderRadius: 7,
          background: showForm ? 'rgba(255,255,255,0.06)' : T.accent,
          border: 'none', color: showForm ? T.text2 : '#fff',
          fontSize: 12, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 6,
          cursor: 'pointer', transition: 'all 140ms ease',
        }}>
          <Plus size={14} />
          {showForm ? 'Cancelar' : 'Adicionar BC'}
        </button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 12 }}>

        {/* Feedback */}
        {success && (
          <div style={{ background: 'rgba(34,197,94,0.06)', border: '1px solid rgba(34,197,94,0.2)', borderRadius: 8, padding: '8px 14px', fontSize: 12, color: T.green, display: 'flex', alignItems: 'center', gap: 8 }}>
            <CheckCircle size={14} /> {success}
          </div>
        )}
        {error && (
          <div style={{ background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 8, padding: '8px 14px', fontSize: 12, color: T.red, display: 'flex', alignItems: 'center', gap: 8 }}>
            <AlertCircle size={14} /> {error}
          </div>
        )}

        {/* Formulário nova BC */}
        {showForm && (
          <div style={{ background: T.bgSurface, border: `1px solid ${T.border}`, borderRadius: 10, padding: '16px 20px' }}>
            <p style={{ fontSize: 13, fontWeight: 500, color: T.text1, marginBottom: 16 }}>Nova BC do TikTok</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
              <div>
                {label('Apelido')}
                <Input value={form.apelido} onChange={v => setForm(f => ({ ...f, apelido: v }))} placeholder="Ex: BC Conta 01" />
              </div>
              <div>
                {label('BC ID')}
                <Input value={form.bc_id} onChange={v => setForm(f => ({ ...f, bc_id: v }))} placeholder="Ex: 7123456789012345678" />
              </div>
            </div>
            <div style={{ marginBottom: 12 }}>
              {label('Access Token')}
              <SecretInput value={form.access_token} onChange={v => setForm(f => ({ ...f, access_token: v }))} placeholder="Cole o access token aqui" />
            </div>
            <div style={{ marginBottom: 16 }}>
              {label('Proxy URL (opcional — recomendado para isolamento)')}
              <Input value={form.proxy_url} onChange={v => setForm(f => ({ ...f, proxy_url: v }))} placeholder="http://usuario:senha@ip:porta" />
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={handleSave} disabled={saving} style={{
                height: 34, padding: '0 16px', borderRadius: 7,
                background: saving ? 'rgba(59,130,246,0.3)' : T.accent,
                border: 'none', color: '#fff', fontSize: 13, fontWeight: 500,
                cursor: saving ? 'not-allowed' : 'pointer',
              }}>
                {saving ? 'Salvando...' : 'Salvar BC'}
              </button>
            </div>
            <p style={{ fontSize: 11, color: T.text3, marginTop: 12 }}>
              O Access Token é armazenado criptografado. O proxy garante que cada BC use um IP diferente.
            </p>
          </div>
        )}

        {/* Lista de BCs */}
        {loading ? (
          <div style={{ fontSize: 12, color: T.text3, textAlign: 'center', padding: 40 }}>Carregando...</div>
        ) : bcs.length === 0 ? (
          <div style={{ background: T.bgSurface, border: `1px solid ${T.border}`, borderRadius: 10, padding: 40, textAlign: 'center' }}>
            <p style={{ fontSize: 13, color: T.text3, marginBottom: 8 }}>Nenhuma BC conectada ainda.</p>
            <p style={{ fontSize: 12, color: T.text3 }}>Clique em "Adicionar BC" para conectar sua primeira conta do TikTok Ads.</p>
          </div>
        ) : (
          bcs.map(bc => (
            <div key={bc.id} style={{ background: T.bgSurface, border: `1px solid ${T.border}`, borderRadius: 10, padding: '14px 16px' }}>

              {/* Header da BC */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: bc.advertiser_accounts.length > 0 ? 12 : 0 }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: bc.ativo ? T.green : T.text3, flexShrink: 0 }} />
                <span style={{ fontSize: 13, fontWeight: 500, color: T.text1, flex: 1 }}>{bc.apelido}</span>
                <span style={{ fontSize: 11, color: T.text3, fontFamily: T.mono }}>BC {bc.bc_id}</span>
                <SyncBadge status={bc.sync_status} />
                {bc.last_sync && (
                  <span style={{ fontSize: 10, color: T.text3 }}>{timeAgo(bc.last_sync)}</span>
                )}
                <button
                  onClick={() => handleSync(bc)}
                  disabled={syncing === bc.id}
                  title="Sincronizar agora"
                  style={{
                    width: 28, height: 28, borderRadius: 6,
                    background: 'rgba(255,255,255,0.04)',
                    border: `1px solid ${T.border}`,
                    color: T.text3, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    cursor: syncing === bc.id ? 'not-allowed' : 'pointer',
                  }}
                >
                  <RefreshCw size={13} style={{ animation: syncing === bc.id ? 'spin 1s linear infinite' : 'none' }} />
                </button>
                <button
                  onClick={() => handleDelete(bc.id)}
                  title="Remover BC"
                  style={{
                    width: 28, height: 28, borderRadius: 6,
                    background: 'rgba(239,68,68,0.04)',
                    border: `1px solid rgba(239,68,68,0.15)`,
                    color: T.red, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    cursor: 'pointer',
                  }}
                >
                  <Trash2 size={13} />
                </button>
              </div>

              {/* Advertiser accounts */}
              {bc.advertiser_accounts.length > 0 && (
                <div style={{ borderTop: `1px solid ${T.borderSub}`, paddingTop: 10 }}>
                  {bc.advertiser_accounts.map(adv => (
                    <div key={adv.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 0' }}>
                      <div style={{ width: 5, height: 5, borderRadius: '50%', background: adv.status === 'ACTIVE' ? T.green : T.text3, flexShrink: 0 }} />
                      <span style={{ fontSize: 12, color: T.text2, flex: 1 }}>
                        {adv.nome ?? `Advertiser #${adv.advertiser_id}`}
                      </span>
                      <span style={{ fontFamily: T.mono, fontSize: 12, color: (adv.balance ?? 0) < 100 ? T.yellow : T.text2 }}>
                        {adv.balance !== null ? toBRL(adv.balance) : '—'}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {bc.sync_error && (
                <p style={{ fontSize: 11, color: T.red, marginTop: 8, padding: '6px 10px', background: 'rgba(239,68,68,0.06)', borderRadius: 6 }}>
                  Erro: {bc.sync_error}
                </p>
              )}
            </div>
          ))
        )}

        {/* Info sobre proxy */}
        <div style={{ background: 'rgba(59,130,246,0.04)', border: '1px solid rgba(59,130,246,0.12)', borderRadius: 8, padding: '10px 14px' }}>
          <p style={{ fontSize: 12, color: T.accent, marginBottom: 4, fontWeight: 500 }}>Como funciona o isolamento de BCs</p>
          <p style={{ fontSize: 11, color: T.text3, lineHeight: 1.6 }}>
            Cada BC usa um proxy dedicado para fazer requests à API do TikTok.
            Isso garante que as contas nunca se cruzem por IP.
            Configure um proxy diferente para cada BC adicionada.
          </p>
        </div>

      </div>

      <style>{`@keyframes spin { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }`}</style>
    </div>
  )
}