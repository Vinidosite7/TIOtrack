'use client'

import { useState, useEffect } from 'react'
import { TrendingUp, TrendingDown, RefreshCw, Calendar, AlertTriangle } from 'lucide-react'
import { T } from '@/lib/tokens'
import { supabase } from '@/lib/supabase'
import { useWorkspaceStore } from '@/store/workspace'

// ── Tipos ──────────────────────────────────────────────────────
type Period = 'hoje' | '7d' | '30d'

type KpiData = {
  receita: number
  gasto: number
  lucro: number
  roas: number
  deltaReceita: number
  deltaGasto: number
  deltaLucro: number
  deltaRoas: number
}

type BC = {
  nome: string
  adv: string
  balance: number
  status: 'ok' | 'warn'
}

type Criativo = {
  nome: string
  score: string
  roas: number
}

type Meta = {
  metaMensal: number
  receitaMes: number
  diasRestantes: number
}

// ── Helpers ────────────────────────────────────────────────────
function toBRL(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })
}

function hoje() {
  return new Date().toISOString().split('T')[0]
}

function diasAtras(n: number) {
  const d = new Date()
  d.setDate(d.getDate() - n)
  return d.toISOString().split('T')[0]
}

function diasRestantesNoMes() {
  const now = new Date()
  const ultimo = new Date(now.getFullYear(), now.getMonth() + 1, 0)
  return ultimo.getDate() - now.getDate()
}

function calcScore(roas: number): string {
  if (roas >= 3.5) return 'S'
  if (roas >= 2.5) return 'A'
  if (roas >= 1.5) return 'B'
  return 'C'
}

const SCORE_STYLE: Record<string, { bg: string; color: string }> = {
  S: { bg: 'rgba(59,130,246,0.15)',  color: T.accent },
  A: { bg: 'rgba(34,197,94,0.12)',   color: T.green  },
  B: { bg: 'rgba(234,179,8,0.10)',   color: T.yellow },
  C: { bg: 'rgba(239,68,68,0.10)',   color: T.red    },
}

// ── Sparkline ──────────────────────────────────────────────────
function Sparkline({ color, points }: { color: string; points: string }) {
  return (
    <svg width={80} height={36}
      style={{ position: 'absolute', bottom: 0, right: 0, opacity: 0.45 }}
      aria-hidden="true"
    >
      <polyline points={points} fill="none" stroke={color} strokeWidth={1.5} strokeLinejoin="round" />
    </svg>
  )
}

// ── KPI Card ───────────────────────────────────────────────────
function KpiCard({ label, value, delta, deltaPositive, sparkColor, sparkPoints, loading }: {
  label: string
  value: string
  delta: string
  deltaPositive: boolean
  sparkColor: string
  sparkPoints: string
  loading?: boolean
}) {
  return (
    <div style={{
      background: T.bgSurface,
      border: `1px solid ${T.border}`,
      borderRadius: 10,
      padding: '14px 16px',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <div style={{ fontSize: 11, color: T.text3, fontWeight: 500, letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: 6 }}>
        {label}
      </div>
      {loading ? (
        <div style={{ height: 22, width: '60%', background: T.border, borderRadius: 4, marginBottom: 8, animation: 'pulse 1.5s ease-in-out infinite' }} />
      ) : (
        <div style={{ fontFamily: T.mono, fontSize: 22, fontWeight: 500, color: T.text1, lineHeight: 1, marginBottom: 8 }}>
          {value}
        </div>
      )}
      <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, fontFamily: T.mono, color: deltaPositive ? T.green : T.red }}>
        {deltaPositive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
        {delta}
      </div>
      <Sparkline color={sparkColor} points={sparkPoints} />
    </div>
  )
}

// ── Topbar ─────────────────────────────────────────────────────
function Topbar({ period, setPeriod, onRefresh, refreshing }: {
  period: Period
  setPeriod: (p: Period) => void
  onRefresh: () => void
  refreshing: boolean
}) {
  const pills: { key: Period; label: string }[] = [
    { key: 'hoje', label: 'Hoje' },
    { key: '7d',   label: '7d'   },
    { key: '30d',  label: '30d'  },
  ]
  return (
    <div style={{
      height: 48,
      borderBottom: `1px solid ${T.border}`,
      display: 'flex',
      alignItems: 'center',
      padding: '0 20px',
      gap: 8,
      flexShrink: 0,
    }}>
      <span style={{ fontSize: 13, fontWeight: 500, color: T.text1 }}>Overview</span>
      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', gap: 6 }}>
        {pills.map(p => (
          <button key={p.key} onClick={() => setPeriod(p.key)} style={{
            height: 26, padding: '0 10px', borderRadius: 6,
            background: period === p.key ? 'rgba(59,130,246,0.1)' : 'rgba(255,255,255,0.04)',
            border: `1px solid ${period === p.key ? 'rgba(59,130,246,0.3)' : T.border}`,
            fontSize: 11, color: period === p.key ? T.accent : T.text2,
            cursor: 'pointer', transition: 'all 140ms ease',
            display: 'flex', alignItems: 'center', gap: 5, fontFamily: T.sans,
          }}>
            {p.key === 'hoje' && <Calendar size={11} />}
            {p.label}
          </button>
        ))}
      </div>
      <button onClick={onRefresh} style={{
        width: 28, height: 28, borderRadius: 6,
        background: 'rgba(255,255,255,0.04)',
        border: `1px solid ${T.border}`,
        color: T.text3,
        display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
      }}>
        <RefreshCw size={13} style={{ animation: refreshing ? 'spin 1s linear infinite' : 'none' }} />
      </button>
    </div>
  )
}

// ── Page ───────────────────────────────────────────────────────
export default function OverviewPage() {
  const { active: workspace } = useWorkspaceStore()
  const [period, setPeriod]   = useState<Period>('hoje')
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [kpi, setKpi]         = useState<KpiData | null>(null)
  const [bcs, setBcs]         = useState<BC[]>([])
  const [criativos, setCriativos] = useState<Criativo[]>([])
  const [meta, setMeta]       = useState<Meta | null>(null)

  async function load(wid: string, p: Period) {
    setLoading(true)
    try {
      const hoje_str   = hoje()
      const ontem_str  = diasAtras(1)
      const from_str   = p === 'hoje' ? hoje_str : p === '7d' ? diasAtras(7) : diasAtras(30)

      // ── Gasto período atual ──────────────────────────────
      const { data: spendData } = await supabase
        .from('ad_spend_daily')
        .select('spend, conversions, conversion_value')
        .eq('workspace_id', wid)
        .gte('dia', from_str)
        .lte('dia', hoje_str)

      const totalSpend  = spendData?.reduce((s, r) => s + (r.spend ?? 0), 0) ?? 0
      const totalConvVal = spendData?.reduce((s, r) => s + (r.conversion_value ?? 0), 0) ?? 0

      // ── Gasto período anterior (mesmo range, antes) ──────
      const diff = p === 'hoje' ? 1 : p === '7d' ? 7 : 30
      const prevFrom = diasAtras(diff * 2)
      const prevTo   = diasAtras(diff)

      const { data: prevSpend } = await supabase
        .from('ad_spend_daily')
        .select('spend, conversion_value')
        .eq('workspace_id', wid)
        .gte('dia', prevFrom)
        .lt('dia', prevTo)

      const prevTotalSpend   = prevSpend?.reduce((s, r) => s + (r.spend ?? 0), 0) ?? 0
      const prevTotalConvVal = prevSpend?.reduce((s, r) => s + (r.conversion_value ?? 0), 0) ?? 0

      // ── Vendas reais (webhook) ───────────────────────────
      const { data: salesData } = await supabase
        .from('conversions')
        .select('valor')
        .eq('workspace_id', wid)
        .eq('status', 'paid')
        .gte('dia', from_str)
        .lte('dia', hoje_str)

      const totalReceita = salesData?.reduce((s, r) => s + (r.valor ?? 0), 0) ?? totalConvVal

      const { data: prevSales } = await supabase
        .from('conversions')
        .select('valor')
        .eq('workspace_id', wid)
        .eq('status', 'paid')
        .gte('dia', prevFrom)
        .lt('dia', prevTo)

      const prevReceita = prevSales?.reduce((s, r) => s + (r.valor ?? 0), 0) ?? prevTotalConvVal

      const lucro     = totalReceita - totalSpend
      const prevLucro = prevReceita - prevTotalSpend
      const roas      = totalSpend > 0 ? totalReceita / totalSpend : 0
      const prevRoas  = prevTotalSpend > 0 ? prevReceita / prevTotalSpend : 0

      const pctDelta = (curr: number, prev: number) =>
        prev > 0 ? Math.round(((curr - prev) / prev) * 100) : 0

      setKpi({
        receita:      totalReceita,
        gasto:        totalSpend,
        lucro,
        roas,
        deltaReceita: pctDelta(totalReceita, prevReceita),
        deltaGasto:   pctDelta(totalSpend, prevTotalSpend),
        deltaLucro:   pctDelta(lucro, prevLucro),
        deltaRoas:    Math.round((roas - prevRoas) * 100) / 100,
      })

      // ── BCs e saldo ──────────────────────────────────────
      const { data: bcData } = await supabase
        .from('advertiser_accounts')
        .select('advertiser_id, nome, balance, status, bc_configs(apelido)')
        .eq('workspace_id', wid)

      const threshold = 100
      setBcs(
        (bcData ?? []).map((a: any) => ({
          nome:    a.bc_configs?.apelido ?? 'BC',
          adv:     `#${a.advertiser_id?.slice(-3)}`,
          balance: a.balance ?? 0,
          status:  (a.balance ?? 0) < threshold ? 'warn' : 'ok',
        }))
      )

      // ── Score de criativos (top 5 por ROAS) ─────────────
      const { data: adData } = await supabase
        .from('ad_spend_daily')
        .select('ad_name, spend, conversion_value')
        .eq('workspace_id', wid)
        .gte('dia', diasAtras(7))
        .not('ad_name', 'is', null)

      const adMap: Record<string, { spend: number; rev: number }> = {}
      ;(adData ?? []).forEach((r: any) => {
        if (!r.ad_name) return
        if (!adMap[r.ad_name]) adMap[r.ad_name] = { spend: 0, rev: 0 }
        adMap[r.ad_name].spend += r.spend ?? 0
        adMap[r.ad_name].rev   += r.conversion_value ?? 0
      })

      const criativosCalc = Object.entries(adMap)
        .map(([nome, v]) => ({
          nome,
          roas:  v.spend > 0 ? Math.round((v.rev / v.spend) * 100) / 100 : 0,
          score: calcScore(v.spend > 0 ? v.rev / v.spend : 0),
        }))
        .sort((a, b) => b.roas - a.roas)
        .slice(0, 5)

      setCriativos(criativosCalc)

      // ── Meta do mês ──────────────────────────────────────
      const { data: prefs } = await supabase
        .from('user_prefs')
        .select('meta_mensal_brl')
        .eq('workspace_id', wid)
        .single()

      const inicioMes = new Date()
      inicioMes.setDate(1)
      const inicioMesStr = inicioMes.toISOString().split('T')[0]

      const { data: mesData } = await supabase
        .from('conversions')
        .select('valor')
        .eq('workspace_id', wid)
        .eq('status', 'paid')
        .gte('dia', inicioMesStr)

      const receitaMes = mesData?.reduce((s, r) => s + (r.valor ?? 0), 0) ?? 0

      setMeta({
        metaMensal:    prefs?.meta_mensal_brl ?? 0,
        receitaMes,
        diasRestantes: diasRestantesNoMes(),
      })

    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => {
    if (workspace?.id) load(workspace.id, period)
  }, [workspace?.id, period])

  function handleRefresh() {
    if (!workspace?.id) return
    setRefreshing(true)
    load(workspace.id, period)
  }

  const warnBcs = bcs.filter(b => b.status === 'warn')
  const metaPct = meta ? Math.min(Math.round((meta.receitaMes / meta.metaMensal) * 100), 100) : 0
  const needPerDay = meta && meta.diasRestantes > 0
    ? Math.round((meta.metaMensal - meta.receitaMes) / meta.diasRestantes)
    : 0

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <Topbar period={period} setPeriod={setPeriod} onRefresh={handleRefresh} refreshing={refreshing} />

      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 12 }}>

        {/* Alerta saldo baixo */}
        {warnBcs.length > 0 && (
          <div style={{
            background: 'rgba(234,179,8,0.06)', border: '1px solid rgba(234,179,8,0.18)',
            borderRadius: 8, padding: '8px 14px',
            display: 'flex', alignItems: 'center', gap: 10,
            fontSize: 12, color: T.yellow,
          }}>
            <AlertTriangle size={14} />
            {warnBcs.map(b => b.nome).join(', ')} — saldo baixo. Recarregue antes de pausar campanhas.
          </div>
        )}

        {/* KPIs */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
          <KpiCard label="Receita" value={toBRL(kpi?.receita ?? 0)}
            delta={`${(kpi?.deltaReceita ?? 0) >= 0 ? '+' : ''}${kpi?.deltaReceita ?? 0}% vs anterior`}
            deltaPositive={(kpi?.deltaReceita ?? 0) >= 0}
            sparkColor={T.green} loading={loading}
            sparkPoints="0,28 13,22 26,24 39,14 52,18 65,8 78,4" />
          <KpiCard label="Gasto em Ads" value={toBRL(kpi?.gasto ?? 0)}
            delta={`${(kpi?.deltaGasto ?? 0) >= 0 ? '+' : ''}${kpi?.deltaGasto ?? 0}% vs anterior`}
            deltaPositive={(kpi?.deltaGasto ?? 0) <= 0}
            sparkColor={T.red} loading={loading}
            sparkPoints="0,24 13,20 26,22 39,18 52,16 65,20 78,18" />
          <KpiCard label="Lucro líquido" value={toBRL(kpi?.lucro ?? 0)}
            delta={`${(kpi?.deltaLucro ?? 0) >= 0 ? '+' : ''}${kpi?.deltaLucro ?? 0}% vs anterior`}
            deltaPositive={(kpi?.deltaLucro ?? 0) >= 0}
            sparkColor={T.accent} loading={loading}
            sparkPoints="0,30 13,26 26,20 39,16 52,12 65,8 78,4" />
          <KpiCard label="ROAS" value={`${(kpi?.roas ?? 0).toFixed(2)}x`}
            delta={`${(kpi?.deltaRoas ?? 0) >= 0 ? '+' : ''}${kpi?.deltaRoas ?? 0}x vs anterior`}
            deltaPositive={(kpi?.deltaRoas ?? 0) >= 0}
            sparkColor={T.accent} loading={loading}
            sparkPoints="0,26 13,22 26,20 39,18 52,14 65,12 78,8" />
        </div>

        {/* BCs + Criativos */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div style={{ background: T.bgSurface, border: `1px solid ${T.border}`, borderRadius: 10, padding: '14px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <span style={{ fontSize: 11, color: T.text3, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Saldo das BCs</span>
              <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, background: 'rgba(59,130,246,0.1)', color: T.accent, fontFamily: T.mono }}>
                {bcs.length} contas
              </span>
            </div>
            {bcs.length === 0 && !loading && (
              <p style={{ fontSize: 12, color: T.text3, textAlign: 'center', padding: '16px 0' }}>
                Nenhuma BC conectada ainda. Vai em Integrações.
              </p>
            )}
            {bcs.map((bc, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0', borderBottom: `1px solid ${T.borderSub}` }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: bc.status === 'warn' ? T.yellow : T.green, flexShrink: 0 }} />
                <span style={{ fontSize: 12, color: T.text1, flex: 1 }}>{bc.nome} · {bc.adv}</span>
                <span style={{ fontFamily: T.mono, fontSize: 12, color: bc.status === 'warn' ? T.yellow : T.text2 }}>
                  {toBRL(bc.balance)}
                </span>
              </div>
            ))}
          </div>

          <div style={{ background: T.bgSurface, border: `1px solid ${T.border}`, borderRadius: 10, padding: '14px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <span style={{ fontSize: 11, color: T.text3, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Score de criativos</span>
              <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, background: 'rgba(59,130,246,0.1)', color: T.accent, fontFamily: T.mono }}>7d</span>
            </div>
            {criativos.length === 0 && !loading && (
              <p style={{ fontSize: 12, color: T.text3, textAlign: 'center', padding: '16px 0' }}>
                Sem dados de anúncios ainda.
              </p>
            )}
            {criativos.map((c, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 0', borderBottom: `1px solid ${T.borderSub}` }}>
                <span style={{ fontSize: 11, color: T.text1, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.nome}</span>
                <div style={{ width: 22, height: 22, borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600, fontFamily: T.mono, ...SCORE_STYLE[c.score] }}>
                  {c.score}
                </div>
                <span style={{ fontFamily: T.mono, fontSize: 11, color: T.text2, minWidth: 36, textAlign: 'right' }}>
                  {c.roas.toFixed(1)}x
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Meta do mês */}
        {meta && meta.metaMensal > 0 && (
          <div style={{ background: T.bgSurface, border: `1px solid ${T.border}`, borderRadius: 10, padding: '14px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <span style={{ fontSize: 11, color: T.text3, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Meta do mês</span>
              <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, background: metaPct >= 100 ? 'rgba(34,197,94,0.1)' : metaPct >= 70 ? 'rgba(59,130,246,0.1)' : 'rgba(234,179,8,0.1)', color: metaPct >= 100 ? T.green : metaPct >= 70 ? T.accent : T.yellow, fontFamily: T.mono }}>
                {metaPct >= 100 ? 'Meta batida!' : metaPct >= 70 ? 'No ritmo' : 'Atenção'}
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 10 }}>
              <span style={{ fontFamily: T.mono, fontSize: 20, color: T.text1 }}>{toBRL(meta.receitaMes)}</span>
              <span style={{ fontSize: 12, color: T.text3 }}>de {toBRL(meta.metaMensal)} · {meta.diasRestantes} dias restantes</span>
            </div>
            <div style={{ height: 3, background: T.border, borderRadius: 2, overflow: 'hidden', marginBottom: 8 }}>
              <div style={{ height: '100%', width: `${metaPct}%`, background: metaPct >= 100 ? T.green : T.accent, borderRadius: 2, transition: 'width 600ms ease' }} />
            </div>
            <div style={{ fontSize: 11, color: T.text3, display: 'flex', alignItems: 'center', gap: 6 }}>
              Precisa de <span style={{ fontFamily: T.mono, color: T.text2 }}>{toBRL(needPerDay)}/dia</span> para bater a meta
            </div>
          </div>
        )}

        {meta && meta.metaMensal === 0 && !loading && (
          <div style={{ background: T.bgSurface, border: `1px solid ${T.border}`, borderRadius: 10, padding: '14px 16px', textAlign: 'center' }}>
            <p style={{ fontSize: 12, color: T.text3 }}>Configure sua meta mensal em Configurações.</p>
          </div>
        )}

      </div>

      <style>{`
        @keyframes pulse { 0%,100% { opacity:1 } 50% { opacity:0.4 } }
        @keyframes spin { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }
      `}</style>
    </div>
  )
}