'use client'

import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleLogin() {
    setLoading(true)
    setError('')

    const { error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) {
      setError('Email ou senha incorretos')
      setLoading(false)
      return
    }

    router.push('/overview')
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: '#080B12',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'Inter, sans-serif',
    }}>
      <div style={{
        width: '100%',
        maxWidth: 400,
        padding: '0 24px',
      }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <span style={{
            fontSize: 28,
            fontWeight: 700,
            color: '#22D3EE',
            letterSpacing: '-0.5px',
          }}>
            Tio<span style={{ color: '#fff' }}>Track</span>
          </span>
          <p style={{ color: '#475569', fontSize: 14, marginTop: 8 }}>
            Sua sala de controle
          </p>
        </div>

        {/* Card */}
        <div style={{
          background: 'rgba(255,255,255,0.03)',
          border: '1px solid rgba(255,255,255,0.07)',
          borderRadius: 16,
          padding: 32,
        }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

            {/* Email */}
            <div>
              <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 6 }}>
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="seu@email.com"
                style={{
                  width: '100%',
                  height: 44,
                  background: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: 10,
                  color: '#E2E8F0',
                  fontSize: 14,
                  padding: '0 14px',
                  outline: 'none',
                  boxSizing: 'border-box',
                }}
              />
            </div>

            {/* Senha */}
            <div>
              <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 6 }}>
                Senha
              </label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                onKeyDown={e => e.key === 'Enter' && handleLogin()}
                style={{
                  width: '100%',
                  height: 44,
                  background: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: 10,
                  color: '#E2E8F0',
                  fontSize: 14,
                  padding: '0 14px',
                  outline: 'none',
                  boxSizing: 'border-box',
                }}
              />
            </div>

            {/* Erro */}
            {error && (
              <p style={{ fontSize: 13, color: '#F87171', textAlign: 'center' }}>
                {error}
              </p>
            )}

            {/* Botão */}
            <button
              onClick={handleLogin}
              disabled={loading || !email || !password}
              style={{
                width: '100%',
                height: 44,
                background: loading ? 'rgba(34,211,238,0.3)' : '#22D3EE',
                color: loading ? '#94A3B8' : '#080B12',
                border: 'none',
                borderRadius: 10,
                fontSize: 14,
                fontWeight: 600,
                cursor: loading ? 'not-allowed' : 'pointer',
                transition: 'all 150ms ease',
                marginTop: 4,
              }}
            >
              {loading ? 'Entrando...' : 'Entrar'}
            </button>

          </div>
        </div>
      </div>
    </div>
  )
}