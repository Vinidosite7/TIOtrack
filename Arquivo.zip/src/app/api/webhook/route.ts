import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()

    // Pega workspace_id do query param
    const { searchParams } = new URL(req.url)
    const workspace_id = searchParams.get('wid')

    if (!workspace_id) {
      return NextResponse.json({ error: 'wid obrigatório' }, { status: 400 })
    }

    // Normaliza o payload — aceita SharkBot e formato genérico
    const venda = normalizePayload(body)

    if (!venda) {
      return NextResponse.json({ error: 'Payload inválido' }, { status: 400 })
    }

    // Salva a conversão
    const { error } = await supabaseAdmin
      .from('conversions')
      .upsert({
        workspace_id,
        external_id:      venda.external_id,
        produto:          venda.produto,
        categoria:        venda.categoria,
        valor:            venda.valor,
        moeda:            'BRL',
        status:           venda.status,
        utm_source:       venda.utm_source,
        utm_medium:       venda.utm_medium,
        utm_campaign:     venda.utm_campaign,
        utm_content:      venda.utm_content,
        utm_term:         venda.utm_term,
        utm_id:           venda.utm_id,
        customer_name:    venda.customer_name,
        customer_phone:   venda.customer_phone,
        payment_platform: venda.payment_platform,
        payment_method:   venda.payment_method,
        dia:              venda.dia,
      }, { onConflict: 'external_id' })

    if (error) {
      console.error('Supabase error:', error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Atualiza o daily_summary
    await updateDailySummary(workspace_id, venda.dia)

    return NextResponse.json({ ok: true, id: venda.external_id })

  } catch (err: any) {
    console.error('Webhook error:', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

// ── Normaliza payloads de diferentes plataformas ───────────────
function normalizePayload(body: any) {
  // SharkBot format
  if (body.transaction_id || body.transactionId) {
    const id = body.transaction_id ?? body.transactionId
    const status = normalizeStatus(body.status ?? body.payment_status)
    const valor = parseFloat(body.amount ?? body.value ?? body.valor ?? '0')
    const dia = body.created_at
      ? body.created_at.split('T')[0]
      : new Date().toISOString().split('T')[0]

    return {
      external_id:      String(id),
      produto:          body.product ?? body.produto ?? body.plan ?? null,
      categoria:        body.category ?? body.categoria ?? null,
      valor,
      status,
      utm_source:       body.utm_source ?? body.utmSource ?? null,
      utm_medium:       body.utm_medium ?? body.utmMedium ?? null,
      utm_campaign:     body.utm_campaign ?? body.utmCampaign ?? null,
      utm_content:      body.utm_content ?? body.utmContent ?? null,
      utm_term:         body.utm_term ?? body.utmTerm ?? null,
      utm_id:           body.utm_id ?? body.utmId ?? null,
      customer_name:    body.customer_name ?? body.name ?? body.nome ?? null,
      customer_phone:   body.customer_phone ?? body.phone ?? body.telefone ?? null,
      payment_platform: 'sharkbot',
      payment_method:   body.payment_method ?? body.method ?? 'pix',
      dia,
    }
  }

  // Formato genérico
  if (body.id && body.valor) {
    return {
      external_id:      String(body.id),
      produto:          body.produto ?? null,
      categoria:        body.categoria ?? null,
      valor:            parseFloat(body.valor),
      status:           normalizeStatus(body.status),
      utm_source:       body.utm_source ?? null,
      utm_medium:       body.utm_medium ?? null,
      utm_campaign:     body.utm_campaign ?? null,
      utm_content:      body.utm_content ?? null,
      utm_term:         body.utm_term ?? null,
      utm_id:           body.utm_id ?? null,
      customer_name:    body.customer_name ?? null,
      customer_phone:   body.customer_phone ?? null,
      payment_platform: body.platform ?? 'manual',
      payment_method:   body.method ?? 'pix',
      dia:              body.dia ?? new Date().toISOString().split('T')[0],
    }
  }

  return null
}

function normalizeStatus(status: string): string {
  const s = (status ?? '').toLowerCase()
  if (['paid', 'pago', 'approved', 'aprovado', 'complete', 'completed'].includes(s)) return 'paid'
  if (['refunded', 'reembolsado', 'refund'].includes(s)) return 'refunded'
  if (['chargeback'].includes(s)) return 'chargeback'
  return 'pending'
}

async function updateDailySummary(workspace_id: string, dia: string) {
  // Recalcula o resumo do dia
  const { data: sales } = await supabaseAdmin
    .from('conversions')
    .select('valor, status')
    .eq('workspace_id', workspace_id)
    .eq('dia', dia)

  const { data: spend } = await supabaseAdmin
    .from('ad_spend_daily')
    .select('spend')
    .eq('workspace_id', workspace_id)
    .eq('dia', dia)

  const { data: prefs } = await supabaseAdmin
    .from('user_prefs')
    .select('custo_produto')
    .eq('workspace_id', workspace_id)
    .single()

  const receita = (sales ?? [])
    .filter(s => s.status === 'paid')
    .reduce((sum, s) => sum + (s.valor ?? 0), 0)

  const vendas_count = (sales ?? []).filter(s => s.status === 'paid').length
  const gasto_ads    = (spend ?? []).reduce((sum, s) => sum + (s.spend ?? 0), 0)
  const custo_pct    = prefs?.custo_produto ?? 0
  const custo_prod   = receita * custo_pct
  const lucro        = receita - gasto_ads - custo_prod
  const roas         = gasto_ads > 0 ? receita / gasto_ads : null
  const margem       = receita > 0 ? (lucro / receita) * 100 : null

  await supabaseAdmin
    .from('daily_summary')
    .upsert({
      workspace_id,
      dia,
      receita_bruta:  receita,
      vendas_count,
      gasto_ads,
      custo_produto:  custo_prod,
      lucro_liquido:  lucro,
      roas,
      margem,
      updated_at:     new Date().toISOString(),
    }, { onConflict: 'workspace_id,dia' })
}