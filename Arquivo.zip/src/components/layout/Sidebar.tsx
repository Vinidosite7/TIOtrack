'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  LayoutDashboard, TrendingUp, ShoppingCart,
  Link2, FileBarChart, Plug, Settings,
} from 'lucide-react'
import { T } from '@/lib/tokens'

const NAV = [
  { to: '/',           icon: LayoutDashboard, label: 'Overview' },
  { to: '/campanhas',  icon: TrendingUp,       label: 'Campanhas' },
  { to: '/vendas',     icon: ShoppingCart,     label: 'Vendas' },
  { to: '/utms',       icon: Link2,            label: 'UTMs' },
  { to: '/relatorios', icon: FileBarChart,     label: 'Relatórios' },
]

const NAV_BOTTOM = [
  { to: '/integracoes',   icon: Plug,     label: 'Integrações' },
  { to: '/configuracoes', icon: Settings, label: 'Configurações' },
]

function NavItem({ to, icon: Icon, label }: {
  to: string
  icon: React.ElementType
  label: string
}) {
  const pathname = usePathname()
  const isActive = pathname === to

  return (
    <Link href={to} title={label} style={{
      width: 36,
      height: 36,
      borderRadius: 8,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: isActive ? T.accent : T.text3,
      background: isActive ? 'rgba(59,130,246,0.12)' : 'transparent',
      transition: 'all 140ms ease',
    }}>
      <Icon size={18} />
    </Link>
  )
}

export default function Sidebar() {
  return (
    <nav style={{
      width: 52,
      background: '#0A0D14',
      borderRight: `1px solid ${T.border}`,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '14px 0',
      gap: 4,
      flexShrink: 0,
      zIndex: 10,
    }}>
      {/* Logo */}
      <div style={{
        width: 28,
        height: 28,
        background: T.accent,
        borderRadius: 7,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 13,
        fontWeight: 700,
        color: '#fff',
        marginBottom: 16,
        flexShrink: 0,
      }}>
        T
      </div>

      {/* Nav principal */}
      {NAV.map(item => (
        <NavItem key={item.to} {...item} />
      ))}

      <div style={{ flex: 1 }} />

      {/* Nav bottom */}
      {NAV_BOTTOM.map(item => (
        <NavItem key={item.to} {...item} />
      ))}
    </nav>
  )
}