export const T = {
  // Backgrounds
  bgBase:    '#07090F',
  bgSurface: '#0D1017',
  bgRaised:  '#131720',

  // Borders
  border:    '#1E2535',
  borderSub: '#131720',

  // Text
  text1: '#E8EDF5',
  text2: '#7A8499',
  text3: '#3D4659',

  // Accent
  accent: '#3B82F6',
  green:  '#22C55E',
  red:    '#EF4444',
  yellow: '#EAB308',

  // Fonts
  mono: "'JetBrains Mono', monospace",
  sans: "'Inter', sans-serif",
} as const;